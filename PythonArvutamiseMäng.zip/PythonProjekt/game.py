import tkinter as tk
import time
import random
import threading
import os
from PIL import Image, ImageTk

PILTIDE_KAUST = os.path.join(os.path.dirname(os.path.abspath(__file__)), "pildid")

# MÄNGU MUUTUJAD

taimer = 20
töötab = True
tase = 1
õige_vastused = 0
õige = 0
scoreboard = []


#Piltide laadimine

def laadi_pildid():

    tulemus = {"õige": [], "vale": []}

# õige vastuse pildid: pilt1.png ja pilt2.png
# vale vastuse pildid: pilt3.png ja pilt4.png

    for nr in [1, 2]: 
        tee = os.path.join(PILTIDE_KAUST, f"pilt{nr}.png")
        if os.path.exists(tee):
            pilt = Image.open(tee).resize((200, 200), Image.LANCZOS)
            tulemus["õige"].append(ImageTk.PhotoImage(pilt))
        
    for nr in [3, 4]: 
        tee = os.path.join(PILTIDE_KAUST, f"pilt{nr}.png")
        if os.path.exists(tee):
            pilt = Image.open(tee).resize((200, 200), Image.LANCZOS)
            tulemus["vale"].append(ImageTk.PhotoImage(pilt))

    return tulemus

# TAIMER

def loendur():
    global taimer, töötab

    while taimer > 0 and töötab:
        taimer_silt.config(text=f"⏱ Aega: {taimer}s    Tase {tase}")
        time.sleep(1)
        taimer -= 1

    if taimer <= 0:
        töötab = False
        mäng_läbi()


# MÄNG LÄBI

def mäng_läbi():
    taimer_silt.config(text="💥 MÄNG LÄBI!")
    tagasiside_silt.config(text=f"Lõplik skoor: {õige_vastused} punkti", fg="#f39c12")
    reaktsioon_silt.config(text="")
    reaktsioon_pilt_silt.config(image="")

    # Salvestab skoori ja uuendab tabeli
    scoreboard.append(õige_vastused)
    uuenda_scoreboard()

    # Keelab nuppude kasutuse
    vasta_nupp.config(state="disabled")
    for nupp in numbri_nupud:
        nupp.config(state="disabled")

    # Näitab (Uue mängu) nuppu
    uus_mäng_nupp.config(state="normal")


# SCOREBOARD

def uuenda_scoreboard():
    
    # Sorteeri: parim skoor esimesena
    sorteeritud = sorted(scoreboard, reverse=True)

    for i, skoor in enumerate(sorteeritud[:10]):
        if i == 0:
            ikoon, värv = "🥇", "#FFD700"
        elif i == 1:
            ikoon, värv = "🥈", "#C0C0C0"
        elif i == 2:
            ikoon, värv = "🥉", "#CD7F32"
        else:
            ikoon, värv = f"{i+1}.", "#ffffff"

        tk.Label(
            scoreboard_sisu,
            text=f"{ikoon}  {skoor} punkti",
            font=("Courier", 12, "bold"),
            bg="#1a1a2e", fg=värv, anchor="w"
        ).pack(fill="x", padx=5, pady=2)


def reset_scoreboard():
    global scoreboard
    scoreboard = []
    uuenda_scoreboard()


# LEVEL SÜSTEEM
# Tase tõuseb iga 5 õige vastuse järel

def loo_tehe():

    global a, b, õige, sümbol

    if tase == 1:
        min_arv, max_arv = 1, 10
        tehted = ["+", "-"]
    elif tase == 2:
        min_arv, max_arv = 1, 50
        tehted = ["+", "-"]    
    elif tase == 3:
        min_arv, max_arv = 1, 20
        tehted = ["+", "-", "*", "/"]
    elif tase == 4:
        min_arv, max_arv = 1, 100
        tehted = ["+", "-", "*", "/"]
    elif tase == 5:
        min_arv, max_arv = 10, 100
        tehted = ["+", "-", "*", "/"]    
    else:
        min_arv, max_arv = 10, 200
        tehted = ["+", "-", "*", "/"]

    sümbol = random.choice(tehted)

    if sümbol == "/":
        # Jagamisel veendub et vastus on alati täisarv
      
        b = random.randint(2, 12)
        a = b * random.randint(1, 10)
    else:
        a = random.randint(min_arv, max_arv)
        b = random.randint(min_arv, max_arv)

    # Lahutamine, suurem arv miinus väiksem (vastus ei ole negatiivne)
    if sümbol == "-" and b > a:
        a, b = b, a

    # Arvuta õige vastus
    if sümbol == "+":
        õige = a + b
    elif sümbol == "-":
        õige = a - b
    elif sümbol == "*":
        õige = a * b
    else:
        õige = a // b

    küsimus_silt.config(text=f"  {a}  {sümbol}  {b}  =  ?  ")


# REAKTSIOONIPILDID

def näita_reaktsioon(oli_õige):
 
## oli_õige=True   pilt1.png või pilt2.png
## oli_õige=False  pilt3.png või pilt4.png
   
    global reaktsioon_pilt

    if oli_õige:
        reaktsioon_silt.config(text="✅ ÕIGE! +5s", fg="#2ecc71")
        valik = pildid["õige"]  # [pilt1, pilt2]
    else:
        reaktsioon_silt.config(text="❌ VALE! -2s", fg="#e74c3c")
        valik = pildid["vale"]  # [pilt3, pilt4]

    
    olemasolevad = [p for p in valik if p]

    if olemasolevad:
        
        valitud = random.choice(olemasolevad)
        reaktsioon_pilt = valitud
        reaktsioon_pilt_silt.config(image=valitud)

    # Peidab reaktsiooni 1.5 sekundi pärast
    aken.after(1500, lambda: (reaktsioon_silt.config(text=""), reaktsioon_pilt_silt.config(image="")))



# VASTUSE KONTROLL

def kontrolli_vastust():
    global taimer, õige_vastused, tase

    if not töötab:
        return

    try:
        vastus = int(ekraan_muutuja.get())
    except ValueError:
        tagasiside_silt.config(text="Sisesta number!", fg="orange")
        return

    ekraan_muutuja.set("")

    if vastus == õige:
        taimer += 5
        õige_vastused += 1
        tagasiside_silt.config(text=f"Õige! +5s    Kokku: {õige_vastused}", fg="#2ecc71")
        näita_reaktsioon(True)

        # Iga 5 õige vastuse järel tase tõuseb
        if õige_vastused % 5 == 0:
            tase += 1
            tagasiside_silt.config(text=f" TASE {tase}!", fg="#f39c12")
    else:
        taimer = max(0, taimer - 2)
        tagasiside_silt.config(text=f"Vale! Õige oli {õige}  |  -2s", fg="#e74c3c")
        näita_reaktsioon(False)

    loo_tehe()



# SISEND

def vajuta(väärtus):
    ekraan_muutuja.set(ekraan_muutuja.get() + str(väärtus))


def kustuta():
    ekraan_muutuja.set(ekraan_muutuja.get()[:-1])


#UUE Mängu alustamine

def uus_mäng():
    global taimer, töötab, tase, õige_vastused, õige

    taimer = 20
    töötab = True
    tase = 1
    õige_vastused = 0
    õige = 0

    ekraan_muutuja.set("")
    tagasiside_silt.config(text="", fg="white")
    reaktsioon_silt.config(text="")
    reaktsioon_pilt_silt.config(image="")
    uus_mäng_nupp.config(state="disabled")

    vasta_nupp.config(state="normal")
    for nupp in numbri_nupud:
        nupp.config(state="normal")

    loo_tehe()

    #taimer uues lõimes
    lõim = threading.Thread(target=loendur, daemon=True)
    lõim.start()


# UI

aken = tk.Tk()
aken.title("ARVUTAMISE MÄNG")
aken.configure(bg="#1a1a2e")
aken.resizable(False, False)


pildid = laadi_pildid()


pea_raam = tk.Frame(aken, bg="#1a1a2e")
pea_raam.pack(padx=10, pady=10)


# Vasak pool: mängu info ja nupud
vasak = tk.Frame(pea_raam, bg="#16213e", bd=2, relief="groove")
vasak.grid(row=0, column=0, padx=10, pady=10, sticky="n")

tk.Label(vasak, text="ARVUTAMISE MÄNG",
         font=("Courier", 16, "bold"), bg="#16213e", fg="#e94560").pack(pady=8)

taimer_silt = tk.Label(vasak, text="⏱ Aega: 20s    Tase 1",
                       font=("Courier", 14), bg="#16213e", fg="#f39c12")
taimer_silt.pack()

küsimus_silt = tk.Label(vasak, text="",
                         font=("Courier", 22, "bold"), bg="#16213e", fg="#ffffff", width=20)
küsimus_silt.pack(pady=10)

ekraan_muutuja = tk.StringVar()
tk.Label(vasak, textvariable=ekraan_muutuja,
         font=("Courier", 30, "bold"), bg="#0f3460", fg="#ffffff",
         width=8, height=1, relief="sunken", anchor="e").pack(padx=10, pady=5)

tagasiside_silt = tk.Label(vasak, text="", font=("Courier", 12), bg="#16213e", fg="#ffffff")
tagasiside_silt.pack()

reaktsioon_silt = tk.Label(vasak, text="", font=("Courier", 14, "bold"), bg="#16213e", fg="#ffffff")
reaktsioon_silt.pack()

reaktsioon_pilt_silt = tk.Label(vasak, bg="#16213e")
reaktsioon_pilt_silt.pack(pady=2)

########################
# Numbrite nupud 

nupu_raam = tk.Frame(vasak, bg="#16213e")
nupu_raam.pack(pady=5)

numbri_nupud = []
W, H = 5, 2  # kõik nupud sama lai (W) ja kõrge (H)

for rida_nr, rida in enumerate([[7, 8, 9], [4, 5, 6], [1, 2, 3]]):
    for veerg_nr, number in enumerate(rida):
        nupp = tk.Button(nupu_raam, text=str(number),
                         width=W, height=H, font=("Courier", 16, "bold"),
                         bg="#0f3460", fg="#ffffff", activebackground="#e94560",
                         command=lambda n=number: vajuta(n))
        nupp.grid(row=rida_nr, column=veerg_nr, padx=2, pady=2)
        numbri_nupud.append(nupp)

# Alumine rida
for veerg_nr, (tekst, fn) in enumerate([("−",  lambda: vajuta("-")),("0",  lambda: vajuta(0)),("⌫", kustuta),]):
    nupp = tk.Button(nupu_raam, text=tekst,
                     width=W, height=H, font=("Courier", 16, "bold"),
                     bg="#0f3460", fg="#ffffff", activebackground="#e94560",
                     command=fn)
    nupp.grid(row=3, column=veerg_nr, padx=2, pady=2)
    numbri_nupud.append(nupp)

vasta_nupp = tk.Button(vasak, text=" VASTA",
                       width=20, height=2, font=("Courier", 14, "bold"),
                       bg="#2ecc71", fg="#1a1a2e", activebackground="#27ae60",
                       command=kontrolli_vastust)
vasta_nupp.pack(pady=5)

uus_mäng_nupp = tk.Button(vasak, text="🔄 UUS MÄNG",
                           width=20, height=2, font=("Courier", 14, "bold"),
                           bg="#f39c12", fg="#1a1a2e", activebackground="#e67e22",
                           state="disabled", command=uus_mäng)
uus_mäng_nupp.pack(pady=5)

##################
# PAREM POOL (scoreboard)

parem = tk.Frame(pea_raam, bg="#16213e", bd=2, relief="groove")
parem.grid(row=0, column=1, padx=10, pady=10, sticky="n")

tk.Label(parem, text="🏆 TULEMUSED",
         font=("Courier", 14, "bold"), bg="#16213e", fg="#FFD700").pack(pady=8)

scoreboard_sisu = tk.Frame(parem, bg="#1a1a2e", width=200, height=250)
scoreboard_sisu.pack(padx=10, pady=5, fill="both")
scoreboard_sisu.pack_propagate(False)

#-------------------------------------
# Mängu alustamine
loo_tehe()

lõim = threading.Thread(target=loendur, daemon=True)
lõim.start()

aken.mainloop()
töötab = False